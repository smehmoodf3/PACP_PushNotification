vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Jan 2006 06:41:10 -0000
vti_extenderversion:SR|4.0.2.8912
