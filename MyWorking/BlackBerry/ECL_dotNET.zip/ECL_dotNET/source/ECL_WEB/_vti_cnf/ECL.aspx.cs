vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Apr 2006 19:31:14 -0000
vti_extenderversion:SR|4.0.2.8912
