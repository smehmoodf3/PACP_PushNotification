vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Sep 2005 20:39:30 -0000
vti_extenderversion:SR|4.0.2.8912
