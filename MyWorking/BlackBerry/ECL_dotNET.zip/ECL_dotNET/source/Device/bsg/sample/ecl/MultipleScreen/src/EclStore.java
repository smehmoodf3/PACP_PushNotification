package bsg.sample.ecl.MultipleScreen.src;
import java.util.Vector;
import net.rim.device.api.util.Persistable;
/**
 * <description> Extends vector and implements persistable for a unique reference.
 */

class EclStore extends Vector implements Persistable{
    EclStore() 
    {  
    }
} 
