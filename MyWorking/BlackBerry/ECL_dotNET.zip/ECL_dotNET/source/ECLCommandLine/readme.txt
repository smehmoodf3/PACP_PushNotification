To run the program
------------------

goto console window and go in the directory where the Application is installed

i)To push to browser type

>ECLConsole channel

ii) To push to catcher

>ECLConsole channel

NOTE: Make sure to modify Settings.config file in the Application folder to set all the properties correctly. You cannot make a successful push until this file has the correct properties.
Also when using the catcher option make sure you have installed the catcher application on your device or simulator. The catcher application is a java based application which can be obtained from our code base.