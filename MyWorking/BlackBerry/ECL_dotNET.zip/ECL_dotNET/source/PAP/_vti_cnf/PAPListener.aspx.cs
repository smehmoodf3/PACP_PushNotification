vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 May 2006 18:58:20 -0000
vti_extenderversion:SR|4.0.2.8912
